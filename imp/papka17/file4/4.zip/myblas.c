#include <string.h>

// Упрощённые определения
typedef enum { CblasRowMajor = 101, CblasColMajor = 102 } CBLAS_LAYOUT;
typedef enum { CblasNoTrans = 111, CblasTrans = 112 } CBLAS_TRANSPOSE;
typedef int MKL_INT;

void cblas_dgemm(const CBLAS_LAYOUT layout,
                 const CBLAS_TRANSPOSE TransA,
                 const CBLAS_TRANSPOSE TransB,
                 const MKL_INT m, const MKL_INT n, const MKL_INT k,
                 const double alpha,
                 const double *A, const MKL_INT lda,
                 const double *B, const MKL_INT ldb,
                 const double beta,
                 double *C, const MKL_INT ldc) {
    
    if (layout != CblasRowMajor) return;
    
    // Копируем C * beta
    if (beta != 1.0) {
        for (int i = 0; i < m * n; i++) {
            C[i] *= beta;
        }
    }
    
    // Простое умножение матриц
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            double sum = 0.0;
            for (int p = 0; p < k; p++) {
                double a_val = (TransA == CblasNoTrans) ? A[i * lda + p] : A[p * lda + i];
                double b_val = (TransB == CblasNoTrans) ? B[p * ldb + j] : B[j * ldb + p];
                sum += a_val * b_val;
            }
            C[i * ldc + j] += alpha * sum;
        }
    }
}