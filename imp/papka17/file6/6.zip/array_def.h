#ifndef ARRAY_DEF_H
#define ARRAY_DEF_H

#include "array_decl.h"
#include <string.h>

#ifndef TYPE
#error "TYPE macro must be defined before including array_def.h"
#endif

#ifndef NAME
#error "NAME macro must be defined before including array_def.h"
#endif

// Реализации функций
void FUNC_NAME(init_)(STRUCT_NAME* vec) {
    vec->n = 0;
    vec->arr = NULL;
    vec->capacity = 0;
}

void FUNC_NAME(destroy_)(STRUCT_NAME* vec) {
    free(vec->arr);
    vec->n = 0;
    vec->arr = NULL;
    vec->capacity = 0;
}

void FUNC_NAME(reserve_)(STRUCT_NAME* vec, int capacity) {
    if (capacity <= vec->capacity) return;
    
    TYPE* new_arr = (TYPE*)realloc(vec->arr, capacity * sizeof(TYPE));
    if (new_arr) {
        vec->arr = new_arr;
        vec->capacity = capacity;
    }
}

int FUNC_NAME(push_)(STRUCT_NAME* vec, TYPE value) {
    if (vec->n >= vec->capacity) {
        int new_cap = vec->capacity == 0 ? 1 : vec->capacity * 2;
        FUNC_NAME(reserve_)(vec, new_cap);
    }
    
    vec->arr[vec->n++] = value;
    return vec->n - 1;
}

TYPE FUNC_NAME(pop_)(STRUCT_NAME* vec) {
    if (vec->n > 0) {
        return vec->arr[--vec->n];
    }
    return (TYPE)0;
}

void FUNC_NAME(resize_)(STRUCT_NAME* vec, int newCnt, TYPE fill) {
    if (newCnt > vec->capacity) {
        FUNC_NAME(reserve_)(vec, newCnt);
    }
    
    if (newCnt > vec->n) {
        for (int i = vec->n; i < newCnt; i++) {
            vec->arr[i] = fill;
        }
    }
    
    vec->n = newCnt;
}

void FUNC_NAME(insert_)(STRUCT_NAME* vec, int where, const TYPE* arr, int num) {
    if (num == 0) return;
    
    int new_size = vec->n + num;
    if (new_size > vec->capacity) {
        int new_cap = vec->capacity == 0 ? new_size : new_size * 2;
        FUNC_NAME(reserve_)(vec, new_cap);
    }
    
    // Сдвигаем существующие элементы
    for (int i = vec->n - 1; i >= where; i--) {
        vec->arr[i + num] = vec->arr[i];
    }
    
    // Вставляем новые
    for (int i = 0; i < num; i++) {
        vec->arr[where + i] = arr[i];
    }
    
    vec->n = new_size;
}

void FUNC_NAME(erase_)(STRUCT_NAME* vec, int where, int num) {
    if (num == 0) return;
    
    // Сдвигаем оставшиеся элементы
    for (int i = where + num; i < vec->n; i++) {
        vec->arr[i - num] = vec->arr[i];
    }
    
    vec->n -= num;
}

#endif