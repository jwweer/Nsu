#ifndef ARRAY_DECL_H
#define ARRAY_DECL_H

#include <stdlib.h>

// Проверяем, что макросы определены
#ifndef TYPE
#error "TYPE macro must be defined before including array_decl.h"
#endif

#ifndef NAME
#error "NAME macro must be defined before including array_decl.h"
#endif

// Создаем уникальные имена через конкатенацию
#define CONCAT(a, b) a##b
#define CONCAT2(a, b) CONCAT(a, b)
#define FUNC_NAME(prefix) CONCAT2(prefix, NAME)
#define STRUCT_NAME CONCAT2(array_, NAME)

// Объявление структуры
typedef struct STRUCT_NAME {
    int n;              // текущее количество элементов
    TYPE* arr;          // массив элементов
    int capacity;       // вместимость буфера
} STRUCT_NAME;

// Объявления функций
void FUNC_NAME(init_)(STRUCT_NAME* vec);
void FUNC_NAME(destroy_)(STRUCT_NAME* vec);
int FUNC_NAME(push_)(STRUCT_NAME* vec, TYPE value);
TYPE FUNC_NAME(pop_)(STRUCT_NAME* vec);
void FUNC_NAME(reserve_)(STRUCT_NAME* vec, int capacity);
void FUNC_NAME(resize_)(STRUCT_NAME* vec, int newCnt, TYPE fill);
void FUNC_NAME(insert_)(STRUCT_NAME* vec, int where, const TYPE* arr, int num);
void FUNC_NAME(erase_)(STRUCT_NAME* vec, int where, int num);

#endif